package com.arctouch.codechallenge.home;

import android.arch.lifecycle.ViewModel;
import android.view.View;

import com.arctouch.codechallenge.repository.MovieRepository;
import com.arctouch.codechallenge.repository.api.TmdbApi;
import com.arctouch.codechallenge.repository.data.Cache;
import com.arctouch.codechallenge.repository.model.Genre;
import com.arctouch.codechallenge.repository.model.Movie;

import java.util.ArrayList;

import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.schedulers.Schedulers;

public class HomeViewModel extends ViewModel {

    private MovieRepository movieRepository = new MovieRepository();

    private void getAllGenres() {
        movieRepository.api.genres(TmdbApi.API_KEY, TmdbApi.DEFAULT_LANGUAGE)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(genreResponse -> {
                    Cache.setGenres(genreResponse.genres);
                    getAllUpcomingMovies();
                });
    }

    private void getAllUpcomingMovies(){
        movieRepository.api.upcomingMovies(TmdbApi.API_KEY, TmdbApi.DEFAULT_LANGUAGE, 1L, TmdbApi.DEFAULT_REGION)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(response -> {
                    for (Movie movie : response.results) {
                        movie.genres = new ArrayList<>();
                        for (Genre genre : Cache.getGenres()) {
                            if (movie.genreIds.contains(genre.id)) {
                                movie.genres.add(genre);
                            }
                        }
                    }

                    recyclerView.setAdapter(new HomeAdapter(response.results));
                    progressBar.setVisibility(View.GONE);
                });
    }
}
